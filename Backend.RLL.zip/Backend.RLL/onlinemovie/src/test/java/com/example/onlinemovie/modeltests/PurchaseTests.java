package com.example.onlinemovie.modeltests;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.*;

import com.example.onlinemovie.model.Product;
import com.example.onlinemovie.model.Purchase;
import com.example.onlinemovie.repository.ProductRepository;
import com.example.onlinemovie.repository.PurchaseRepository;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;


@RunWith(SpringRunner.class)
@SpringBootTest
class PurchaseTests {
	
	@Autowired
	PurchaseRepository repository;

	@Test
	void test() {
		//fail("Not yet implemented");
		

		System.out.println("good to go");
		Purchase ps=new Purchase();
		ps.setCustomer(null);
		ps.setDop(null);
		ps.setId(1);
		ps.setProductname("RRR");
		ps.setQuantity(1);
		ps.setTotalcost(350);
		ps.setTransactionid("TSL25455994");
		
		assertNotNull(repository.save(ps));
		
	}

}
