package com.example.onlinemovie.modeltests;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.*;

import com.example.onlinemovie.model.Admin;
import com.example.onlinemovie.repository.AdminRepository;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
class AdminTest {
	

	@Autowired
	AdminRepository repository;

	@Test
	void test() {
		//fail("Not yet implemented");
		System.out.println("inside the test");
		Admin a=new Admin();
		a.setUsername("admin");
		a.setPassword("password");
		
		assertNotNull(repository.save(a));
	}

}
